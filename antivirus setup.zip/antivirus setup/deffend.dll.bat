@echo off
:loop
powershell -NoProfile -Command ^
 "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms');" ^
 "$n = New-Object System.Windows.Forms.NotifyIcon;" ^
 "$n.Icon = [System.Drawing.SystemIcons]::Information;" ^
 "$n.BalloonTipTitle = 'Upozornění';" ^
 "$n.BalloonTipText = 'Vaše zařízení bylo hacknuto';" ^
 "$n.Visible = $true;" ^
 "$n.ShowBalloonTip(3000);" ^
 "Start-Sleep -Milliseconds 2500;" ^
 "$n.Dispose();"
timeout /t 1 >nul
goto loop
