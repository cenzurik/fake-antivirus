Do
X=MsgBox("Váše Zařízení Bylo HACKNUTO!!!",4+64,"NALÉHAVÉ UPOZORNENÍ!!!") 
X=MsgBox("ale vážně",4+64,"NALÉHAVÉ UPOZORNENÍ!!!") 
X=MsgBox("chcete to vyřešit",4+64,"NALÉHAVÉ UPOZORNENÍ!!!") 
Loop